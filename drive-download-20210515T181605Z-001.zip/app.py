from flask import Flask, request, render_template

app = Flask(__name__)


@app.route('/', methods =["GET", "POST"])
def data():
    if request.method == "POST":
        search = request.form.get("search")
        val = request.form.get("choice")

        return "you searched"+ search+"and choice = "+val
    return render_template("index.html")

if __name__  ==  '__main__':
    app.run()